# No more scroll jacking

Prevents scroll jacking whilst a meta key is held.

> Why isn't this turned on by default?

Perhaps I'll get around to making this an option, but I know that it breaks some sites, so it's simpler to opt-in to the anti-scroll jacking. I've already gotten into the habit of holding shift when scrolling these nasties already!

## Icon

Icons a derivative of made by [Pixelmeetup](https://www.flaticon.com/authors/pixelmeetup) from [www.flaticon.com](https://www.flaticon.com/ "Flaticon") is licensed by [CC 3.0 BY](http://creativecommons.org/licenses/by/3.0/ "Creative Commons BY 3.0")
